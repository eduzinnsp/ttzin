const { Client } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const gerarNitro = require("./functions/gerarNitro");

const client = new Client({ intents: 32767 });

client.config = require("./config.json");
client.db = new JsonDatabase({ databasePath: "./db.json" });
client.login(client.config.token);

client.on("ready", () => {
    console.log(`Bot online!`);
    console.log(client.user.id)
});

let gerando = new Set();
client.on("messageCreate", async (msg) => {
    if (msg.author.bot) return;
    
    if (msg.content == "setchannel") {
        if (msg.author.id !== "1179154326170636400") return;

        client.db.push(`${msg.guild.id}.channels`, msg.channel.id);
        msg.delete();
    }
    if (msg.content == "setlogs") {
        if (msg.author.id !== "1179154326170636400") return;

        client.db.set(`${msg.guild.id}.logs`, msg.channel.id);
        msg.delete();
    }

    if (msg.content == "gerar") {
        let guild = client.db.get(`${msg.guild.id}`);
        if (!guild) return;
        if (guild.channels.length <= 0) return msg.delete();
        
        if (gerando.has(msg.author.id)) return msg.delete();
        let mm = await msg.reply({ content: `Aguarde, gerando nitro....` });

        gerando.add(msg.author.id);
        await gerarNitro(client, msg, mm, gerando);
    }

    if (msg.content == "exit") {
        if (msg.author.id !== "1179154326170636400") return;

        client.db.delete(msg.guild.id);
        msg.guild.leave().catch(() => { return })
    }
})

client.on("guildCreate", async (guild) => {
    await client.db.set(`${guild.id}`, guild.id);
    await client.db.set(`${guild.id}.channels`, []);
})

process.on('unhandledRejection', (reason, promise) => {
    return;
})

process.on('uncaughtException', (error) => {
    return;
})