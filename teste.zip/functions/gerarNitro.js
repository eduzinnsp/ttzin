const puppeteer = require("puppeteer");

module.exports = async function gerar(client, msg, msg1, gerando) {
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();

    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 OPR/105.0.0.0');
    await page.goto("https://www.opera.com/gx/discord-nitro");

    await page.bringToFront()
    await page.waitForSelector("#claim-button");
    await page.click("#claim-button"); 

    await browser.on("targetcreated", async (pag) => {
        if (pag.type() == "page") {
            const pagg = await pag.page();

            if (pagg) {
                const url = await pagg.url();
                await msg1.edit({ content: `✅ Nitro **gerado** com sucesso!` })

                msg.author.send({ content: `# Sistema Gerador de Nitro #\n\n➜ _Desenvolvido por @eduzinnsp_\n➜ [Resgate seu nitro aqui!](${url})` })
                .catch(() => {
                    client.channels.cache.get(client.db.get(`${msg.guild.id}.logs`)).send({ content: `# Sistema Gerador de Nitro #\n\n➜ _Desenvolvido por @eduzinnsp_\n➜ [Resgate seu nitro aqui!](${url})` });
                })

                gerando.delete(msg.author.id);
            }
        }
    })
}