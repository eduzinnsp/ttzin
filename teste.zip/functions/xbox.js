const puppeteer = require("puppeteer");

async function xbox(client, msg, msg1, gerando) {
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();

    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 OPR/76.0.4017.123');
    await page.goto("https://www.xbox.com/pt-BR/xbox-game-pass#join");

    await browser.on("targetcreated", async (pagA) => {
        if (pagA.type() == 'page') {
            const pagg = await pagA.page();

            if (pagg) {
                await pagg.waitForSelector("#PageContent > div > div:nth-child(1) > div.ModuleContainer-module__container___pkhPl.ProductDetailsHeader-module__container___zvKSX > div.FadeContainers-module__fadeIn___5xlsD.FadeContainers-module__widthInherit___5fuOa > div > button");
                await pagg.click("#PageContent > div > div:nth-child(1) > div.ModuleContainer-module__container___pkhPl.ProductDetailsHeader-module__container___zvKSX > div.FadeContainers-module__fadeIn___5xlsD.FadeContainers-module__widthInherit___5fuOa > div > button");

                await pagg.waitForSelector("#i0116");
                await pagg.type("#i0116", "testemesmo@outlook.com");
                await pagg.click("#idSIButton9");

                await pagg.waitForSelector("#i0118");
                await pagg.type("#i0118", "joaogomes123433@@");
                await pagg.click("#idSIButton9");
            }
        }
    });

    await page.waitForSelector("#ultimate > div > div.intro > div.c-group > a");
    await page.click("#ultimate > div > div.intro > div.c-group > a");


}

xbox()